import{O as i}from"./index-GtaDKUif.js";const n=o=>["",...i].includes(o);export{n as i};

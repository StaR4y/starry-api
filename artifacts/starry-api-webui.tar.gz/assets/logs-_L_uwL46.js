import{br as r,ag as t}from"./index-DZP6fFq-.js";const e={list(){return r(t.get("/admin/logs"))},performance(){return r(t.get("/admin/performance"))}};export{e as l};

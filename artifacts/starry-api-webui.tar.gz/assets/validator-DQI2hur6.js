import{I as i}from"./index-DrMmoGYt.js";const n=o=>["",...i].includes(o);export{n as i};

import{O as i}from"./index-D_QwhEl_.js";const n=o=>["",...i].includes(o);export{n as i};

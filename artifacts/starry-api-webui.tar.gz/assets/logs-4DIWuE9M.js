import{u as r,h as t}from"./index-CJ7-IVa-.js";const a={list(){return r(t.get("/admin/logs"))},performance(){return r(t.get("/admin/performance"))}};export{a as l};

import{O as i}from"./index-h2YoJFN8.js";const n=o=>["",...i].includes(o);export{n as i};

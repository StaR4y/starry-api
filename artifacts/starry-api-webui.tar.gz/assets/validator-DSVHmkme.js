import{O as i}from"./index-Uymw7xPk.js";const n=o=>["",...i].includes(o);export{n as i};

import{aw as c}from"./index-CTe7P_mm.js";const e=(...a)=>s=>{a.forEach(o=>{c(o)?o(s):o.value=s})};export{e as c};

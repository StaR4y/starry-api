import{I as i}from"./index-CPHZJseH.js";const n=o=>["",...i].includes(o);export{n as i};

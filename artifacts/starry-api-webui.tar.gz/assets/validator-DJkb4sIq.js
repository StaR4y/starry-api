import{I as i}from"./index-ChpUtYj2.js";const n=o=>["",...i].includes(o);export{n as i};

import{O as i}from"./index-CTe7P_mm.js";const n=o=>["",...i].includes(o);export{n as i};

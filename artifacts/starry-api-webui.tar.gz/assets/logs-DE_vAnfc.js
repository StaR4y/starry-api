import{bx as r,ak as t}from"./index-D_QwhEl_.js";const e={list(){return r(t.get("/admin/logs"))},performance(){return r(t.get("/admin/performance"))}};export{e as l};

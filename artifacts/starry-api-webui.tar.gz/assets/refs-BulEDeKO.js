import{av as c}from"./index-Bf6cmVzA.js";const e=(...a)=>s=>{a.forEach(o=>{c(o)?o(s):o.value=s})};export{e as c};

import{I as i}from"./index-DH8Uufyv.js";const n=o=>["",...i].includes(o);export{n as i};

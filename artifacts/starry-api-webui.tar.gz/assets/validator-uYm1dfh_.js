import{I as i}from"./index-CZC4v7iI.js";const n=o=>["",...i].includes(o);export{n as i};

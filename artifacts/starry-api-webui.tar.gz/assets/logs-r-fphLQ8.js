import{by as r,al as t}from"./index-GtaDKUif.js";const e={list(){return r(t.get("/admin/logs"))},performance(){return r(t.get("/admin/performance"))}};export{e as l};

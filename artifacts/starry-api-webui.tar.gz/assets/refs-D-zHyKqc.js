import{ap as c}from"./index-C2Di1fjA.js";const e=(...a)=>s=>{a.forEach(o=>{c(o)?o(s):o.value=s})};export{e as c};

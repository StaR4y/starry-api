import{by as r,ak as t}from"./index-h2YoJFN8.js";const e={list(){return r(t.get("/admin/logs"))},performance(){return r(t.get("/admin/performance"))}};export{e as l};

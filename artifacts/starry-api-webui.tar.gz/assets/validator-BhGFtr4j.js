import{O as i}from"./index-CPZy3svT.js";const n=o=>["",...i].includes(o);export{n as i};

import{av as c}from"./index-h2YoJFN8.js";const e=(...a)=>s=>{a.forEach(o=>{c(o)?o(s):o.value=s})};export{e as c};

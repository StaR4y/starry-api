import{O as i}from"./index-SMcOF7ft.js";const n=o=>["",...i].includes(o);export{n as i};

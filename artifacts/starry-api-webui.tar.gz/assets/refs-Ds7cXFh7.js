import{ap as c}from"./index-DZP6fFq-.js";const e=(...a)=>s=>{a.forEach(o=>{c(o)?o(s):o.value=s})};export{e as c};

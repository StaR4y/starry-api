import{O as i}from"./index-5GxCgeM-.js";const n=o=>["",...i].includes(o);export{n as i};

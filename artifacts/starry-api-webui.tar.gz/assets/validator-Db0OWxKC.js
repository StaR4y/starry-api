import{I as i}from"./index-BgQkdclX.js";const n=o=>["",...i].includes(o);export{n as i};

import{u as r,h as t}from"./index-DcEluN88.js";const a={list(){return r(t.get("/admin/logs"))},performance(){return r(t.get("/admin/performance"))}};export{a as l};

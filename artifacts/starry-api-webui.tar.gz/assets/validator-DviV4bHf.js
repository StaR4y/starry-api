import{I as i}from"./index-C2Di1fjA.js";const n=o=>["",...i].includes(o);export{n as i};

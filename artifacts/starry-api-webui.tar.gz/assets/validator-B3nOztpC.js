import{I as i}from"./index-DZP6fFq-.js";const n=o=>["",...i].includes(o);export{n as i};

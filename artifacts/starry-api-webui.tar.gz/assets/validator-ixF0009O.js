import{O as i}from"./index-Bf6cmVzA.js";const n=o=>["",...i].includes(o);export{n as i};
